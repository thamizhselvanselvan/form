function contact() {
    let name,email,message;
    name = document.getElementById("name").value;
    email = document.getElementById("email").value;
    message = document.getElementById("message").value;


    if (email == 0 && password == 0 && message == 0) {
        alert('Please fill in email and password');
    } else if (email == 0) {
        alert("Please fill the email")
    } else if (password.length == 0) {
        alert("Please fill the password")
    } else if (password.length > 8) {
        alert('Max of 8 digite')
    }else if (message == 0) {
        alert('Please fill the message')
    } else {
        localStorage.setItem('name',name);
        localStorage.setItem('email', email);
        localStorage.setItem('message', message);
        alert('Successfull')
    }
}