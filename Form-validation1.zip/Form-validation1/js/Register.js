function store() {
    let email, password;
    // name = document.getElementById("name").value;
    email = document.getElementById("email").value;
    password = document.getElementById("password").value;


    if (email == 0 && password == 0) {
        alert('Please fill in email and password');
    } else if (email == 0) {
        alert("Please fill the email")
    } else if (password.length == 0) {
        alert("Please fill the password")
    } else if (password.length > 8) {
        alert('Max of 8 digite')
    } else {
        // localStorage.setItem('name',name);
        localStorage.setItem('email', email);
        localStorage.setItem('password', password);
        alert('Successfull Register')
        window.location.href = "./Login.html"
    }
}


const data = localStorage.getItem("email");
console.log(data)
const data1 = localStorage.getItem("password");
console.log(data1)

const lEmail = document.getElementById("lEmail").value;
const lPassword = document.getElementById("lPassword").value;

function cheack() {

    const lEmail = document.getElementById("lEmail").value;
    const lPassword = document.getElementById("lPassword").value;

    if (lEmail == 0 && lPassword == 0) {
        alert('Please fill in email and password');
    } else if (data === lEmail && data1 == lPassword) {
        alert("successful Login")
        window.location.href = "./Aboutus.html"
    } else {
        alert("Resart login")

    }
}

function logout() {
    localStorage.setItem('email', "");
    localStorage.setItem('password', "");
    window.location.href = "./Register.html"
}



